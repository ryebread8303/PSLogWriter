enum LogLevel {
    Verbose
    Info
    Warning
    Error
    Critical
}